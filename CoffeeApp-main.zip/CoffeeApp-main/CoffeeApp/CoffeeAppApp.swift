//
//  CoffeeAppApp.swift
//  CoffeeApp
//
//  Created by Shahad Bagarish on 14/09/2022.
//

import SwiftUI

@main
struct CoffeeAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView(iced: true, suger: true)
        }
    }
}
